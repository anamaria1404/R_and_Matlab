%% Examen Parcial 3 MIA
% 5 - Winequality
%% Limpieza General
clear all;
close all;
clc;

%% carga de datos
[datos, Y]  =  xlsread("Dry_Bean_Dataset.xlsx","Dry_Beans_Dataset","A2:Q13612");
% selección de variables:
X1=datos(:,1); %Área
X2=datos(:,2); %Perímetro
X3=datos(:,7); %Área Convexa
X = [X1 X2 X3];
% escogimos usar las variables a prueba y error viendo la J
Ynum = zeros(size(Y));
llaves = unique(Y);
V = {1,2,3,4,5,6,7};
uniq = containers.Map(llaves,V);

for j = 1:size(Y)
    Ynum(j) = uniq(Y{j});
end

%No escalamiento
% %% Escalamiento:
% % escalamiento (normalización)
% media=mean(X);
% desviacion=std(X);
% temp= bsxfun(@minus, X, media);
% X=bsxfun(@rdivide, temp, desviacion);


%% Partición:
% cv = cvpartition(Ynum,'holdout',0.15);
load cvG3.mat

Xtrain = X(training(cv),:);
Ytrain = Ynum(training(cv));
% Datos de prueba.
Xtest = X(test(cv),:);
Ytest = Ynum(test(cv));


%% Creación de Dummies
% generar dummies en Train
for i=1:size(Ytrain,1)
    for j=2:8
        if Ytrain(i,1)==j-1
            Ytrain(i,j)=1;
        else
            Ytrain(i,j)=0;
        end
    end
end

Ytrain=Ytrain(:,2:end);


% generar dummies en Test
for i=1:size(Ytest,1)
    for j=2:8
        if Ytest(i,1)==j-1
            Ytest(i,j)=1;
        else
            Ytest(i,j)=0;
        end
    end
end

Ytest=Ytest(:,2:end);

Xtrain = Xtrain';
Ytrain = Ytrain';
Xtest = Xtest';
Ytest = Ytest';

%% Creación del modelo neuronal (NO CORRER)
% Jtrain = zeros(10,10);
% Jtest = zeros (10,10);
% ExacTrain = zeros(10,10);
% ExacTest = zeros(10,10);
% for x=1:10    
%     for y = 1:10
%         red=feedforwardnet([x y]); %empezar con una capa e ir calibrando
%         red.trainFcn="trainrp";
%         % para clasificacion usar rp o scg
%         red=train(red,Xtrain,Ytrain);
%             % Simulación
%         Ygtrain = red(Xtrain);
%         Ygtrain = round(Ygtrain);
%         YgTest=red(Xtest);
%         YgTest = round(YgTest);
%         for j = 1:size(Ygtrain,2)
%             if Ygtrain(1,j)==-1
%                 Ygtrain(1,j)=0;
%             end
%         end
%         for j = 1:size(YgTest,2)
%             if YgTest(1,j)==-1
%                 YgTest(1,j)=0;
%             end
%         end
%         J(y,x)=perform(red,Ytrain,Ygtrain);
%         % Medidas de Desempeño en vase a variable 1 ""
%         a1 = confusionmat(Ytrain(5,:),Ygtrain(5,:));
%         a2 = confusionmat(Ytest(5,:),YgTest(5,:));
%         % %Exactitud, en base a los vinos de calificación 6
%         ExacTrain(y,x) = sum(diag(a1))/sum(sum(a1));
%         ExacTest(y,x) = sum(diag(a2))/sum(sum(a2));
%         
%     end
% end

%% Eleccion del modelo
% red2 = feedforwardnet([7 10]);
% red2.trainFcn='trainrp'; 
% red2 = train(red2,Xtrain,Ytrain);

load redp3.mat
%% Medidas de desempeño del modelo

% Simulacion TRAIN 
Yg2=red2(Xtrain);
% Ciclo de redondeo
Yg2=round(Yg2);
for i=1:7
    for j=1:size(Yg2,2)
        if Yg2(i,j) == -1
            Yg2(i,j) = 0;
        end
        if Yg2(i,j) == 2
            Yg2(i,j) = 1;
        end
    end
end

J2=perform(red2,Ytrain,Yg2);
performanceTrain = zeros(7,3); %7 variables, 3 medidas de desempeño por cada una
                            % 1 = Accuracy
                            % 2 = Precision
                            % 3 = Recall
% Desempeño TRAIN
for i=1:7
    temp=confusionmat(Ytrain(i,:),Yg2(i,:));
    figure(i);
    confusionchart(temp)
    performanceTrain(i,1) = sum(diag(temp))/sum(sum(temp));
    performanceTrain(i,2) = temp([1])/(temp([1])+temp([2])); %Cambiar indices de medidas de desempeño
    performanceTrain(i,3) = temp([1])/(temp([1])+temp([3]));
end


%% Simulacion TEST
YgS2=red2(Xtest);
YgS2=round(YgS2);
performanceTest= zeros(7,3);

% Ciclo de redondeo
YgS2=round(YgS2);
for i=1:7
    for j=1:size(YgS2,2)
        if YgS2(i,j) == -1
            YgS2(i,j) = 0;
        end
        if YgS2(i,j) == 2
            YgS2(i,j) = 1;
        end
    end
end

% Desempeño TEST

for i=1:7
    temp=confusionmat(Ytest(i,:),YgS2(i,:));
    figure(i);
    confusionchart(temp)
    performanceTest(i,1)=sum(diag(temp))/sum(sum(temp));
    performanceTest(i,2) = temp([1])/(temp([1])+temp([2]));
    performanceTest(i,3) = temp([1])/(temp([1])+temp([3]));
end


AccuTrain =  mean(performanceTrain(:,1));
PrecTrain =  mean(performanceTrain(:,2));
RecTrain =  mean(performanceTrain(:,3));

AccuTest =  mean(performanceTest(:,1));
PrecTest =  mean(performanceTest(:,2));
RecTest =  mean(performanceTest(:,3));
[AccuTrain PrecTrain RecTrain]
[AccuTest PrecTest RecTest]